package com.qingtuo.travel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.theme.darkColorScheme
import top.yukonga.miuix.kmp.theme.lightColorScheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val followsSystemDark = isSystemInDarkTheme()
            val preferences = remember {
                getSharedPreferences("appearance", MODE_PRIVATE)
            }
            var appearanceMode by remember {
                mutableIntStateOf(preferences.getInt("mode", 0).coerceIn(0, 2))
            }
            val dark = when (appearanceMode) {
                1 -> true
                2 -> false
                else -> followsSystemDark
            }

            SideEffect {
                WindowCompat.getInsetsController(window, window.decorView).apply {
                    isAppearanceLightStatusBars = !dark
                    isAppearanceLightNavigationBars = !dark
                }
            }

            MiuixTheme(colors = if (dark) darkColorScheme() else lightColorScheme()) {
                HomeScreen(
                    appearanceMode = appearanceMode,
                    onAppearanceModeChange = { mode ->
                        appearanceMode = mode
                        preferences.edit().putInt("mode", mode).apply()
                    },
                )
            }
        }
    }
}
