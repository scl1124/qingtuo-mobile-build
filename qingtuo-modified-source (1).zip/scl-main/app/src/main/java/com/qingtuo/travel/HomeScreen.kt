package com.qingtuo.travel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import top.yukonga.miuix.kmp.basic.Button
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.theme.MiuixTheme
import java.time.LocalDate
import java.time.LocalTime

private data class TripRow(val trip: Trip, val boardTime: String?, val boardMin: Int?)

private fun minutesOf(time: String?): Int? {
    if (time == null) return null
    val parts = time.split(":")
    if (parts.size != 2) return null
    val h = parts[0].toIntOrNull() ?: return null
    val m = parts[1].toIntOrNull() ?: return null
    return h * 60 + m
}

private fun currentMinutes(): Int {
    val now = LocalTime.now()
    return now.hour * 60 + now.minute
}

private fun countdownText(diff: Int): String = when {
    diff <= 0 -> "即将到站，请尽快上车"
    diff < 60 -> "还有 $diff 分钟"
    else -> "还有 ${diff / 60} 小时 ${diff % 60} 分钟"
}

private fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    } catch (_: Exception) {
    }
}

private fun dial(context: Context, phone: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    } catch (_: Exception) {
    }
}

@Composable
fun HomeScreen() {
    val context = LocalContext.current
    val scrollBehavior = MiuixScrollBehavior()

    var routeIndex by rememberSaveable { mutableIntStateOf(0) }
    var webUrl by rememberSaveable { androidx.compose.runtime.mutableStateOf<String?>(null) }
    var webTitle by rememberSaveable { androidx.compose.runtime.mutableStateOf("") }
    var selectedImage by rememberSaveable { androidx.compose.runtime.mutableStateOf<String?>(null) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedImage = uri?.toString()
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        }
    }
    var nowMin by remember { mutableIntStateOf(currentMinutes()) }
    LaunchedEffect(Unit) {
        while (true) {
            nowMin = currentMinutes()
            delay(30_000L)
        }
    }

    val route = Timetable.routes[routeIndex]
    val rows = route.trips.map { trip ->
        val board = route.timeAt(trip, route.boardStation)
        TripRow(trip, board, minutesOf(board))
    }
    val next = rows.firstOrNull { !it.trip.cancelled && it.boardMin != null && it.boardMin >= nowMin }

    val today = LocalDate.now()
    val isToday = today.monthValue == Timetable.MONTH && today.dayOfMonth == Timetable.DAY

    val secondary = MiuixTheme.colorScheme.onSurfaceVariantSummary

    Box(Modifier.fillMaxSize()) {
    if (webUrl != null) {
        Column(Modifier.fillMaxSize().background(MiuixTheme.colorScheme.background)) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { webUrl = null }, colors = ButtonDefaults.buttonColors()) { Text("返回") }
                Text(webTitle, modifier = Modifier.padding(start = 12.dp), fontSize = 17.sp, fontWeight = FontWeight.Medium)
            }
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx -> WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    webViewClient = WebViewClient()
                    loadUrl(webUrl!!)
                } },
                update = { view -> if (view.url != webUrl) view.loadUrl(webUrl!!) }
            )
        }
    } else {
    Scaffold(
        topBar = {
            TopAppBar(title = "临一行", scrollBehavior = scrollBehavior)
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(scrollBehavior.nestedScrollConnection),
            contentPadding = PaddingValues(top = innerPadding.calculateTopPadding(), bottom = 96.dp),
        ) {
            item { Spacer(Modifier.height(12.dp)) }

            // 方向切换
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Timetable.routes.forEachIndexed { index, r ->
                        val selected = index == routeIndex
                        Button(
                            onClick = { routeIndex = index },
                            modifier = Modifier.weight(1f),
                            colors = if (selected) {
                                ButtonDefaults.buttonColorsPrimary()
                            } else {
                                ButtonDefaults.buttonColors()
                            },
                        ) {
                            Text(
                                text = r.title,
                                color = if (selected) {
                                    MiuixTheme.colorScheme.onPrimary
                                } else {
                                    MiuixTheme.colorScheme.onSurface
                                },
                            )
                        }
                    }
                }
            }

            // 时刻表日期提醒
            if (!isToday) {
                item {
                    Card(
                        modifier = Modifier
                            .padding(horizontal = 12.dp)
                            .padding(bottom = 12.dp),
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text(
                                text = "当前内置的是 ${Timetable.DATE_LABEL} 的时刻表",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "客服每天会更换，今天的班次请以最新通知为准。",
                                fontSize = 13.sp,
                                color = secondary,
                            )
                        }
                    }
                }
            }

            // 下一班
            item {
                Card(
                    modifier = Modifier
                        .padding(horizontal = 12.dp)
                        .padding(bottom = 12.dp),
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        if (next != null) {
                            Text(
                                text = "下一班 · ${route.boardStation}上车",
                                fontSize = 13.sp,
                                color = secondary,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = next.boardTime ?: "—",
                                fontSize = 40.sp,
                                fontWeight = FontWeight.Bold,
                                color = MiuixTheme.colorScheme.primary,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = countdownText((next.boardMin ?: nowMin) - nowMin),
                                fontSize = 15.sp,
                            )
                            Spacer(Modifier.height(4.dp))
                            val extra = route.timeAt(next.trip, route.extraStation) ?: "不经过"
                            Text(
                                text = "${next.trip.plate} · ${route.extraLabel} $extra",
                                fontSize = 13.sp,
                                color = secondary,
                            )
                        } else {
                            Text(
                                text = "今天的班次已全部过站",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = Timetable.TIP,
                            fontSize = 12.sp,
                            color = secondary,
                        )
                    }
                }
            }

            // 全部班次
            item { SmallTitle(text = "今日班次 · ${Timetable.DATE_LABEL}") }
            items(rows) { row ->
                val passed = row.boardMin != null && row.boardMin < nowMin
                val dim = row.trip.cancelled || passed
                val tag = when {
                    row.trip.cancelled -> "减班"
                    row === next -> "下一班"
                    passed -> "已过"
                    else -> ""
                }
                Card(
                    modifier = Modifier
                        .padding(horizontal = 12.dp)
                        .padding(bottom = 12.dp),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .alpha(if (dim) 0.45f else 1f)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = row.boardTime ?: "—",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                            )
                            val extra = route.timeAt(row.trip, route.extraStation) ?: "不经过"
                            val plate = if (row.trip.plate.isEmpty()) "" else "${row.trip.plate} · "
                            Text(
                                text = "$plate${route.extraLabel} $extra",
                                fontSize = 13.sp,
                                color = secondary,
                            )
                        }
                        if (tag.isNotEmpty()) {
                            Text(
                                text = tag,
                                fontSize = 14.sp,
                                color = if (tag == "下一班") MiuixTheme.colorScheme.primary else secondary,
                            )
                        }
                    }
                }
            }

            // 出行前先看
            item { SmallTitle(text = "出行前先看") }
            item {
                LinkCard(
                    title = "高德地图 · 路线与路况",
                    subtitle = "看公交路线、路堵不堵",
                    onClick = { webTitle = "高德地图"; webUrl = Timetable.AMAP_URL },
                )
            }
            item {
                LinkCard(
                    title = "新途云 · 车票余量",
                    subtitle = "看车票多不多、车挤不挤（可能需要在微信里打开）",
                    onClick = { webTitle = "新途云"; webUrl = Timetable.XINTUYUN_URL },
                )
            }
            item {
                LinkCard(
                    title = "百度智慧交通 · 拥堵与客流",
                    subtitle = "看路堵不堵、出行人多不多",
                    onClick = { webTitle = "百度路况"; webUrl = Timetable.BAIDU_URL },
                )
            }

            // 票价说明与客服
            item { SmallTitle(text = "票价说明") }
            item {
                Card(
                    modifier = Modifier
                        .padding(horizontal = 12.dp)
                        .padding(bottom = 12.dp),
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Timetable.priceNotes.forEachIndexed { i, note ->
                            if (i > 0) Spacer(Modifier.height(8.dp))
                            Text(text = note, fontSize = 14.sp)
                        }
                    }
                }
            }
            item {
                LinkCard(
                    title = "客车客服电话",
                    subtitle = Timetable.SERVICE_PHONE,
                    onClick = { dial(context, Timetable.SERVICE_PHONE) },
                )
            }

            item { Spacer(Modifier.height(24.dp).navigationBarsPadding()) }
        }
    }
    }
    // 底部液态玻璃快捷入口：保留原时刻表与票价说明
    Row(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .navigationBarsPadding()
            .clip(RoundedCornerShape(24.dp))
            .background(MiuixTheme.colorScheme.background.copy(alpha = 0.94f))
            .padding(horizontal = 6.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ShortcutButton("高德", "路线导航", Modifier.weight(1f)) { webTitle = "高德地图"; webUrl = Timetable.AMAP_URL }
        ShortcutButton("百度路况", "拥堵查询", Modifier.weight(1f)) { webTitle = "百度路况"; webUrl = Timetable.BAIDU_URL }
        ShortcutButton("新途云", "车票余量", Modifier.weight(1f)) { webTitle = "新途云"; webUrl = Timetable.XINTUYUN_URL }
        ShortcutButton("我的图片", "选择照片", Modifier.weight(1f)) { imagePicker.launch("image/*") }
    }
    if (selectedImage != null && webUrl == null) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { selectedImage = null }) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("我的图片", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().height(420.dp),
                        factory = { ctx -> android.widget.ImageView(ctx).apply {
                            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                            setImageURI(Uri.parse(selectedImage))
                        } },
                        update = { it.setImageURI(Uri.parse(selectedImage)) }
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { selectedImage = null }, modifier = Modifier.fillMaxWidth()) { Text("关闭") }
                }
            }
        }
    }
    }
}

@Composable
private fun ShortcutButton(title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(MiuixTheme.colorScheme.background.copy(alpha = 0.94f))
            .clickable(onClick = onClick)
            .padding(horizontal = 3.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MiuixTheme.colorScheme.onSurface)
        Spacer(Modifier.height(2.dp))
        Text(subtitle, fontSize = 9.sp, color = MiuixTheme.colorScheme.onSurfaceVariantSummary, maxLines = 1)
    }
}

@Composable
private fun LinkCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .padding(horizontal = 12.dp)
            .padding(bottom = 12.dp)
            .clickable { onClick() },
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 13.sp,
                color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
            )
        }
    }
}
