package com.qingtuo.travel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import top.yukonga.miuix.kmp.basic.Button
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.theme.MiuixTheme
import java.time.LocalDate
import java.time.LocalTime

private data class TripRow(val trip: Trip, val boardTime: String?, val boardMin: Int?)

private fun minutesOf(time: String?): Int? {
    if (time == null) return null
    val parts = time.split(":")
    if (parts.size != 2) return null
    val h = parts[0].toIntOrNull() ?: return null
    val m = parts[1].toIntOrNull() ?: return null
    return h * 60 + m
}

private fun currentMinutes(): Int {
    val now = LocalTime.now()
    return now.hour * 60 + now.minute
}

private fun countdownText(diff: Int): String = when {
    diff <= 0 -> "即将到站，请尽快上车"
    diff < 60 -> "还有 $diff 分钟"
    else -> "还有 ${diff / 60} 小时 ${diff % 60} 分钟"
}

private fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    } catch (_: Exception) {
    }
}

private fun dial(context: Context, phone: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    } catch (_: Exception) {
    }
}

@Composable
fun HomeScreen(appearanceMode: Int, onAppearanceModeChange: (Int) -> Unit) {
    val context = LocalContext.current
    val appVersionName = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }
            .getOrNull()
            ?.takeIf { it.isNotBlank() }
            ?: "未知"
    }
    val scrollBehavior = MiuixScrollBehavior()

    var routeIndex by rememberSaveable { mutableIntStateOf(0) }
    var webUrl by rememberSaveable { androidx.compose.runtime.mutableStateOf<String?>(null) }
    var webTitle by rememberSaveable { androidx.compose.runtime.mutableStateOf("") }
    var selectedImage by rememberSaveable { androidx.compose.runtime.mutableStateOf<String?>(null) }
    var showAmapChoices by rememberSaveable { androidx.compose.runtime.mutableStateOf(false) }
    var settingsOpen by rememberSaveable { androidx.compose.runtime.mutableStateOf(false) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedImage = uri?.toString()
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        }
    }
    BackHandler(enabled = webUrl != null || settingsOpen) {
        if (webUrl != null) webUrl = null else settingsOpen = false
    }
    var nowMin by remember { mutableIntStateOf(currentMinutes()) }
    LaunchedEffect(Unit) {
        while (true) {
            nowMin = currentMinutes()
            delay(30_000L)
        }
    }

    val route = Timetable.routes[routeIndex]
    val rows = route.trips.map { trip ->
        val board = route.timeAt(trip, route.boardStation)
        TripRow(trip, board, minutesOf(board))
    }
    val next = rows.firstOrNull { !it.trip.cancelled && it.boardMin != null && it.boardMin >= nowMin }

    val today = LocalDate.now()
    val isToday = today.monthValue == Timetable.MONTH && today.dayOfMonth == Timetable.DAY

    val secondary = MiuixTheme.colorScheme.onSurfaceVariantSummary

    Box(Modifier.fillMaxSize()) {
    if (webUrl != null) {
        Column(Modifier.fillMaxSize().background(MiuixTheme.colorScheme.background)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(webTitle, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            }
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx -> WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    webViewClient = WebViewClient()
                    loadUrl(webUrl!!)
                } },
                update = { view -> if (view.url != webUrl) view.loadUrl(webUrl!!) }
            )
        }
    } else if (settingsOpen) {
    Scaffold(
        topBar = {
            TopAppBar(title = "我的设置", scrollBehavior = scrollBehavior)
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("外观模式", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Card {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("选择应用外观", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(6.dp))
                    Text("默认跟随手机系统，也可以固定使用深色或浅色。", fontSize = 13.sp, color = secondary)
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        listOf("跟随系统", "深色", "浅色").forEachIndexed { index, label ->
                            val selected = appearanceMode == index
                            Button(
                                onClick = { onAppearanceModeChange(index) },
                                modifier = Modifier.weight(1f),
                                colors = if (selected) ButtonDefaults.buttonColorsPrimary() else ButtonDefaults.buttonColors(),
                            ) {
                                Text(
                                    text = label,
                                    color = if (selected) MiuixTheme.colorScheme.onPrimary else MiuixTheme.colorScheme.onSurface,
                                    fontSize = 12.sp,
                                )
                            }
                        }
                    }
                }
            }
            SmallTitle(text = "应用信息")
            Card {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("临一行", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(4.dp))
                    Text("版本 $appVersionName", fontSize = 13.sp, color = secondary)
                    Spacer(Modifier.height(4.dp))
                    Text("出行与车次信息", fontSize = 13.sp, color = secondary)
                }
            }
        }
    }
    } else {
    Scaffold(
        topBar = {
            TopAppBar(title = "临一行", scrollBehavior = scrollBehavior)
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(scrollBehavior.nestedScrollConnection),
            contentPadding = PaddingValues(top = innerPadding.calculateTopPadding(), bottom = 96.dp),
        ) {
            item { Spacer(Modifier.height(12.dp)) }
            // 方向切换
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Timetable.routes.forEachIndexed { index, r ->
                        val selected = index == routeIndex
                        Button(
                            onClick = { routeIndex = index },
                            modifier = Modifier.weight(1f),
                            colors = if (selected) {
                                ButtonDefaults.buttonColorsPrimary()
                            } else {
                                ButtonDefaults.buttonColors()
                            },
                        ) {
                            Text(
                                text = r.title,
                                color = if (selected) {
                                    MiuixTheme.colorScheme.onPrimary
                                } else {
                                    MiuixTheme.colorScheme.onSurface
                                },
                            )
                        }
                    }
                }
            }

            // 时刻表日期提醒
            if (!isToday) {
                item {
                    Card(
                        modifier = Modifier
                            .padding(horizontal = 12.dp)
                            .padding(bottom = 12.dp),
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text(
                                text = "当前内置的是 ${Timetable.DATE_LABEL} 的时刻表",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "客服每天会更换，今天的班次请以最新通知为准。",
                                fontSize = 13.sp,
                                color = secondary,
                            )
                        }
                    }
                }
            }

            // 下一班
            item {
                Card(
                    modifier = Modifier
                        .padding(horizontal = 12.dp)
                        .padding(bottom = 12.dp),
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        if (next != null) {
                            Text(
                                text = "下一班 · ${route.boardStation}上车",
                                fontSize = 13.sp,
                                color = secondary,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = next.boardTime ?: "—",
                                fontSize = 40.sp,
                                fontWeight = FontWeight.Bold,
                                color = MiuixTheme.colorScheme.primary,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = countdownText((next.boardMin ?: nowMin) - nowMin),
                                fontSize = 15.sp,
                            )
                            Spacer(Modifier.height(4.dp))
                            val extra = route.timeAt(next.trip, route.extraStation) ?: "不经过"
                            Text(
                                text = "${next.trip.plate} · ${route.extraLabel} $extra",
                                fontSize = 13.sp,
                                color = secondary,
                            )
                        } else {
                            Text(
                                text = "今天的班次已全部过站",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = Timetable.TIP,
                            fontSize = 12.sp,
                            color = secondary,
                        )
                    }
                }
            }

            // 全部班次
            item { SmallTitle(text = "今日班次 · ${Timetable.DATE_LABEL}") }
            items(rows) { row ->
                val passed = row.boardMin != null && row.boardMin < nowMin
                val dim = row.trip.cancelled || passed
                val tag = when {
                    row.trip.cancelled -> "减班"
                    row === next -> "下一班"
                    passed -> "已过"
                    else -> ""
                }
                Card(
                    modifier = Modifier
                        .padding(horizontal = 12.dp)
                        .padding(bottom = 12.dp),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .alpha(if (dim) 0.45f else 1f)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = row.boardTime ?: "—",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                            )
                            val extra = route.timeAt(row.trip, route.extraStation) ?: "不经过"
                            val plate = if (row.trip.plate.isEmpty()) "" else "${row.trip.plate} · "
                            Text(
                                text = "$plate${route.extraLabel} $extra",
                                fontSize = 13.sp,
                                color = secondary,
                            )
                        }
                        if (tag.isNotEmpty()) {
                            Text(
                                text = tag,
                                fontSize = 14.sp,
                                color = if (tag == "下一班") MiuixTheme.colorScheme.primary else secondary,
                            )
                        }
                    }
                }
            }

            // 出行前先看
            item { SmallTitle(text = "出行前先看") }
            item {
                LinkCard(
                    title = "高德地图 · 路线与路况",
                    subtitle = "看公交路线、路堵不堵",
                    onClick = { showAmapChoices = true },
                )
            }
            item {
                LinkCard(
                    title = "新途云 · 车票余量",
                    subtitle = "看车票多不多、车挤不挤（可能需要在微信里打开）",
                    onClick = { webTitle = "新途云"; webUrl = Timetable.XINTUYUN_URL },
                )
            }
            item {
                LinkCard(
                    title = "百度智慧交通 · 拥堵与客流",
                    subtitle = "看路堵不堵、出行人多不多",
                    onClick = { webTitle = "百度路况"; webUrl = Timetable.BAIDU_URL },
                )
            }

            // 票价说明与客服
            item { SmallTitle(text = "票价说明") }
            item {
                Card(
                    modifier = Modifier
                        .padding(horizontal = 12.dp)
                        .padding(bottom = 12.dp),
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Timetable.priceNotes.forEachIndexed { i, note ->
                            if (i > 0) Spacer(Modifier.height(8.dp))
                            Text(text = note, fontSize = 14.sp)
                        }
                    }
                }
            }
            item {
                LinkCard(
                    title = "客车客服电话",
                    subtitle = Timetable.SERVICE_PHONE,
                    onClick = { dial(context, Timetable.SERVICE_PHONE) },
                )
            }

            item { Spacer(Modifier.height(24.dp).navigationBarsPadding()) }
        }
    }
    }
    // Floating, translucent glass-style navigation bar.
    val navShape = RoundedCornerShape(30.dp)
    Row(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .navigationBarsPadding()
            .shadow(22.dp, navShape)
            .clip(navShape)
            .background(MiuixTheme.colorScheme.background.copy(alpha = 0.84f))
            .border(1.dp, MiuixTheme.colorScheme.onSurface.copy(alpha = 0.16f), navShape)
            .padding(horizontal = 8.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ShortcutButton(ShortcutIcon.Amap, "高德导航", Modifier.weight(1f)) {
            settingsOpen = false
            selectedImage = null
            webUrl = null
            showAmapChoices = true
        }
        ShortcutButton(ShortcutIcon.Traffic, "百度路况", Modifier.weight(1f)) {
            settingsOpen = false
            selectedImage = null
            showAmapChoices = false
            webTitle = "百度路况"
            webUrl = Timetable.BAIDU_URL
        }
        ShortcutButton(ShortcutIcon.Ticket, "新途车票", Modifier.weight(1f)) {
            settingsOpen = false
            selectedImage = null
            showAmapChoices = false
            webTitle = "新途云"
            webUrl = Timetable.XINTUYUN_URL
        }
        ShortcutButton(ShortcutIcon.MiniSchedule, "车次微图", Modifier.weight(1f)) {
            settingsOpen = false
            webUrl = null
            showAmapChoices = false
            selectedImage = null
            imagePicker.launch("image/*")
        }
        ShortcutButton(ShortcutIcon.Settings, "我的设置", Modifier.weight(1f)) {
            webUrl = null
            selectedImage = null
            showAmapChoices = false
            settingsOpen = true
        }
    }
    if (showAmapChoices) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAmapChoices = false }) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("打开高德地图", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("可在应用内查看路线，或跳转到高德地图 App、系统浏览器。", fontSize = 14.sp, color = secondary)
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = {
                            showAmapChoices = false
                            webTitle = "高德公交导航"
                            webUrl = Timetable.AMAP_URL
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("应用内 WebView 打开") }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            val launchIntent = context.packageManager.getLaunchIntentForPackage("com.autonavi.minimap")
                            if (launchIntent != null) {
                                showAmapChoices = false
                                context.startActivity(launchIntent)
                            } else {
                                Toast.makeText(context, "未检测到高德地图 App，请选择网页版", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("打开高德地图 App") }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            showAmapChoices = false
                            openUrl(context, Timetable.AMAP_URL)
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("浏览器打开网页版") }
                    Spacer(Modifier.height(4.dp))
                    Button(onClick = { showAmapChoices = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("取消")
                    }
                }
            }
        }
    }
    if (selectedImage != null && webUrl == null) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { selectedImage = null }) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("车次微图", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().height(420.dp),
                        factory = { ctx -> android.widget.ImageView(ctx).apply {
                            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                            setImageURI(Uri.parse(selectedImage))
                        } },
                        update = { it.setImageURI(Uri.parse(selectedImage)) }
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { selectedImage = null }, modifier = Modifier.fillMaxWidth()) { Text("关闭") }
                }
            }
        }
    }
    }
}

private enum class ShortcutIcon { Amap, Traffic, Ticket, MiniSchedule, Settings }

@Composable
private fun ShortcutButton(icon: ShortcutIcon, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 2.dp, vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        NavigationGlyph(icon, Modifier.size(22.dp), MiuixTheme.colorScheme.primary)
        Spacer(Modifier.height(3.dp))
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = MiuixTheme.colorScheme.onSurface, maxLines = 1)
    }
}

@Composable
private fun NavigationGlyph(icon: ShortcutIcon, modifier: Modifier = Modifier, tint: androidx.compose.ui.graphics.Color) {
    Canvas(modifier) {
        val u = size.width / 24f
        val stroke = 1.9f * u
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) {
            drawLine(tint, Offset(x1 * u, y1 * u), Offset(x2 * u, y2 * u), strokeWidth = stroke, cap = StrokeCap.Round)
        }
        fun ring(x: Float, y: Float, radius: Float) {
            drawCircle(tint, radius * u, Offset(x * u, y * u), style = Stroke(width = stroke))
        }
        fun dot(x: Float, y: Float, radius: Float = 1.25f) {
            drawCircle(tint, radius * u, Offset(x * u, y * u))
        }
        when (icon) {
            ShortcutIcon.Amap -> {
                ring(12f, 8f, 4.6f)
                dot(12f, 8f, 1.35f)
                line(8.7f, 11.2f, 12f, 21f)
                line(15.3f, 11.2f, 12f, 21f)
            }
            ShortcutIcon.Traffic -> {
                line(7f, 3f, 7f, 18f); line(17f, 3f, 17f, 18f)
                line(7f, 3f, 17f, 3f); line(7f, 18f, 17f, 18f)
                dot(12f, 6.5f); dot(12f, 10.5f); dot(12f, 14.5f)
                line(12f, 18f, 12f, 22f); line(9f, 22f, 15f, 22f)
            }
            ShortcutIcon.Ticket -> {
                line(4f, 5f, 20f, 5f); line(4f, 19f, 20f, 19f)
                line(4f, 5f, 4f, 19f); line(20f, 5f, 20f, 19f)
                line(12f, 7.5f, 12f, 9.5f); line(12f, 11f, 12f, 13f); line(12f, 14.5f, 12f, 16.5f)
            }
            ShortcutIcon.MiniSchedule -> {
                line(4f, 4f, 20f, 4f); line(4f, 20f, 20f, 20f)
                line(4f, 4f, 4f, 20f); line(20f, 4f, 20f, 20f)
                line(4f, 9f, 20f, 9f); line(4f, 14f, 20f, 14f)
                line(9f, 9f, 9f, 20f); line(15f, 9f, 15f, 20f)
            }
            ShortcutIcon.Settings -> {
                ring(12f, 12f, 5.2f); ring(12f, 12f, 2f)
                line(12f, 2f, 12f, 5f); line(12f, 19f, 12f, 22f)
                line(2f, 12f, 5f, 12f); line(19f, 12f, 22f, 12f)
                line(4.9f, 4.9f, 7f, 7f); line(17f, 17f, 19.1f, 19.1f)
                line(17f, 7f, 19.1f, 4.9f); line(4.9f, 19.1f, 7f, 17f)
            }
        }
    }
}

@Composable
private fun LinkCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .padding(horizontal = 12.dp)
            .padding(bottom = 12.dp)
            .clickable { onClick() },
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 13.sp,
                color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
            )
        }
    }
}
