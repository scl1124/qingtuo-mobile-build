plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

// 如果编译时提示找不到 miuix 的某个版本，只需要改这一行
val miuixVersion = "0.9.2"
val composeVersion = "1.12.0"

android {
    namespace = "com.qingtuo.travel"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.qingtuo.travel"
        minSdk = 26
        targetSdk = 36
        versionCode = 3
        versionName = "0.3.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("top.yukonga.miuix.kmp:miuix-ui:$miuixVersion")

    implementation("org.jetbrains.compose.runtime:runtime:$composeVersion")
    implementation("org.jetbrains.compose.foundation:foundation:$composeVersion")
    implementation("org.jetbrains.compose.ui:ui:$composeVersion")

    implementation("androidx.activity:activity-compose:1.10.1")
}
